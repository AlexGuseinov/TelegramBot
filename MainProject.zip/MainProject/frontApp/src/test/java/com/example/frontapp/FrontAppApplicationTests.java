package com.example.frontapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FrontAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
