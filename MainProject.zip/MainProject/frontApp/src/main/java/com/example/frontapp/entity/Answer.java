package com.example.frontapp.entity;


import jakarta.persistence.*;
import lombok.*;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
//@Entity
public class Answer {

    public String id;

    public String text;
}
