package com.example.frontapp.controller;

import com.example.frontapp.entity.Answer;
import com.example.frontapp.entity.User;
import com.example.frontapp.repos.UserRepo;
import com.example.frontapp.services.AnswerSenderService;
import lombok.RequiredArgsConstructor;
import org.json.JSONObject;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequiredArgsConstructor
public class RabbitController {
    private final AnswerSenderService answerSenderService;
    private final UserRepo userRepo;

//    @GetMapping("/")
//    public String get(){
//       return "simple text";
//    }
    @PostMapping("/post")
    public ResponseEntity<?> sendMessage(@RequestBody String message){
        JSONObject jsonObject = new JSONObject(message);

        String text = jsonObject.getString("text");
        String chatId = jsonObject.getString("chatId");

        Answer answer = new Answer(chatId,text);

        System.out.println(text + " " + chatId);
        answerSenderService.sendToQueue(answer);
        return ResponseEntity.ok("it's a okay message");
    }

    @GetMapping("/get")
    public String getMock(){
         return "working!!!";
    }
    @GetMapping("/getall")
    public List<User> getAllUsers(){
        return userRepo.findAll();
    }


//    @PostMapping
//    public void getMsg(@RequestParam String msg){
//         answerSenderService.sendToQueue(msg);
//    }
}
