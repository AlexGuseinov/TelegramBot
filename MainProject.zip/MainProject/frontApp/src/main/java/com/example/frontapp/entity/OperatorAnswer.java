package com.example.frontapp.entity;


public class OperatorAnswer {
    private long id;
    private String string ;
    
}
