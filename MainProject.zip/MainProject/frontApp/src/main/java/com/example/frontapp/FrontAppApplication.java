package com.example.frontapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FrontAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(FrontAppApplication.class, args);
    }

}
