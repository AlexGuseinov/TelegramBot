package com.example.damnedtgbot.services.abstracts;

import org.telegram.telegrambots.meta.api.objects.replykeyboard.ReplyKeyboardMarkup;

public interface KeyboardButtons {
    ReplyKeyboardMarkup languageButtons();
}
